package com.example.myapplication;

public class Food {
    public String foodName;
    public String calories;

    public Food(String foodName, String calories) {
        this.foodName = foodName;
        this.calories = calories;
    }
}
